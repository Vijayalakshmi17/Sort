package com.example.hp.sort;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button b1;
    TextView t2,t3;
    EditText t1;
    private  int[] a2;
    private String[] a1; //input which is integer,converted to string


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=findViewById(R.id.button);
        t1=(EditText)findViewById(R.id.input);
        t2=(TextView)findViewById(R.id.asc);
        t3=(TextView)findViewById(R.id.desc);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                a1=t1.getText().toString().split(",");
              Asort(a1);
              Dsort(a1);
            }
        });



        //initialising integer list


    }

    public void Asort(String[] a1)
    {
        a2=new int[a1.length];//to get the length of the string
        for(int i=0;i<a1.length;i++)
        {
            a2[i]=Integer.parseInt(a1[i]);//to store the copy of the array so it is in integer and we can compare
        }
        for(int i=0;i<a2.length;i++)
        {
            for(int j=0;j<(a2.length-1);j++)
            {
                if(a2[j]>a2[j+1])
                {
                    int temp=a2[j];
                    a2[j]=a2[j+1];
                    a2[j+1]=temp;

                }
            }
        }
        String op=" ";
        for(int i=0;i<a2.length;i++)
        {
            op=op+" "+a2[i];
            t2.setText(op);
        }
    }

    public void Dsort(String[] a1)
    {
        a2=new int[a1.length];//to get the length of the string
        for(int i=0;i<a1.length;i++)
        {
            a2[i]=Integer.parseInt(a1[i]);//to store the copy of the array so it is in integer and we can compare
        }
        for(int i=0;i<a2.length;i++)
        {
            for(int j=0;j<(a2.length-1);j++)
            {
                if(a2[j]<a2[j+1])
                {
                    int temp=a2[j];
                    a2[j]=a2[j+1];
                    a2[j+1]=temp;

                }
            }
        }
        String op=" ";
        for(int i=0;i<a2.length;i++)
        {
            op=op+" "+a2[i];
            t3.setText(op);
        }
    }

}
